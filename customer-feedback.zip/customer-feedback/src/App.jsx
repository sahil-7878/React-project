import './App.css'
import FeedbackForm from './components/feedbackform'
function App() {

  return (
    <>
    <FeedbackForm />

    </>
  )
}

export default App
